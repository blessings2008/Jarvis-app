package com.bless.jarvis.network

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object RetrofitClient {
    // Your deployed Render URL. Update this if you redeploy elsewhere.
    private const val BASE_URL = "https://jarvis-ai-27rf.onrender.com/"

    // Longer timeout because Render's free tier spins down when idle —
    // the first request after inactivity can take 30-50s to wake up.
    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    val api: JarvisApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(JarvisApi::class.java)
    }
}
